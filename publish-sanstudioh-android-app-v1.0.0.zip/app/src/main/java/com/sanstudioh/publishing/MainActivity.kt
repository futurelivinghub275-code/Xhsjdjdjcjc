package com.sanstudioh.publishing

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Module(val slug:String,val label:String,val icon:androidx.compose.ui.graphics.vector.ImageVector)
val modules=listOf(
Module("articles","Articles",Icons.Default.Article),Module("videos","Videos",Icons.Default.PlayCircle),
Module("polls","Polls",Icons.Default.Poll),Module("anime","Anime Database",Icons.Default.LiveTv),
Module("seasonal-anime","Seasonal Anime",Icons.Default.CalendarMonth),Module("daily-anime","Daily Anime",Icons.Default.Today),
Module("characters","Characters",Icons.Default.Person),Module("anime-birthdays","Anime Birthdays",Icons.Default.Cake),
Module("media","Media Library",Icons.Default.PhotoLibrary),Module("team","Team & Contributors",Icons.Default.Groups),
Module("payments","Payments & Earnings",Icons.Default.Payments),Module("notifications","Notifications",Icons.Default.Notifications),
Module("settings","Settings",Icons.Default.Settings))

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

@Composable fun App(){
 var page by remember{mutableStateOf("Dashboard")}
 MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFE50914),background=Color(0xFF090909),surface=Color(0xFF121212))){
  Row(Modifier.fillMaxSize().background(Color(0xFF090909))){
   NavigationRail(containerColor=Color(0xFF0D0D0D)){
    Spacer(Modifier.height(16.dp));Text("S",color=Color(0xFFE50914),fontSize=28.sp,fontWeight=FontWeight.Black)
    Spacer(Modifier.height(18.dp))
    listOf("Dashboard" to Icons.Default.Dashboard,"Create" to Icons.Default.AddCircle,"All Posts" to Icons.Default.DynamicFeed,"Team" to Icons.Default.Groups).forEach{(n,i)->
     NavigationRailItem(selected=page==n,onClick={page=n},icon={Icon(i,n)},label={Text(n,fontSize=9.sp)})
    }
   }
   Column(Modifier.fillMaxSize()){
    TopAppBar(title={Column{Text("SANSTUDIOH",fontWeight=FontWeight.Black);Text(page,fontSize=12.sp,color=Color.Gray)}},
     actions={IconButton({}){Icon(Icons.Default.Search,"Search")};IconButton({}){Icon(Icons.Default.AccountCircle,"Profile")}})
    when(page){
     "Dashboard"->Dashboard{page=it};"Create"->Create();"All Posts"->Posts();"Team"->Team()
     else->ModulePage(page)
    }
   }
  }
 }
}

@Composable fun Dashboard(open:(String)->Unit){
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text("Publishing Dashboard",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Manage SANSTUDIOH content from one place.",color=Color.Gray)}
  item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Posts","0");Stat("Drafts","0");Stat("Pending","0")}}
  item{Button({open("Create")},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Create New")}}
  item{Text("Publishing",fontSize=18.sp,fontWeight=FontWeight.Bold)}
  items(modules.take(9)){m->Card(Modifier.fillMaxWidth().clickable{open(m.label)}){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(m.icon,null,tint=Color(0xFFE50914));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(m.label,fontWeight=FontWeight.SemiBold);Text("Open publishing module",fontSize=12.sp,color=Color.Gray)};Icon(Icons.Default.ChevronRight,null)}}}
 }
}
@Composable fun Stat(t:String,v:String){Card(Modifier.weight(1f)){Column(Modifier.padding(12.dp)){Text(v,fontSize=22.sp,fontWeight=FontWeight.Bold);Text(t,fontSize=11.sp,color=Color.Gray)}}}

@Composable fun Create(){
 var title by remember{mutableStateOf("")};var body by remember{mutableStateOf("")};var type by remember{mutableStateOf("Article")}
 LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Text("Create",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Publish structured SANSTUDIOH content.",color=Color.Gray)}
  item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Article","Video","Poll").forEach{FilterChip(type==it,{type=it},{Text(it)})}}}
  item{OutlinedTextField(title,{title=it},Modifier.fillMaxWidth(),label={Text("Title")})}
  item{OutlinedTextField(body,{body=it},Modifier.fillMaxWidth().height(260.dp),label={Text("Content")},minLines=10)}
  item{Text("Production editor will support inline images/videos, media library, autosave and recovery.",fontSize=12.sp,color=Color.Gray)}
  item{Button({},Modifier.fillMaxWidth(),enabled=title.isNotBlank()){Icon(Icons.Default.Publish,null);Spacer(Modifier.width(8.dp));Text("Publish $type")}}
 }
}
@Composable fun Posts(){Column(Modifier.fillMaxSize().padding(16.dp)){Text("All Posts",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("Real activity will appear after SANSTUDIOH Core is connected.",color=Color.Gray);Spacer(Modifier.height(16.dp));Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp)){Icon(Icons.Default.CloudOff,null);Spacer(Modifier.width(12.dp));Column{Text("Backend not connected");Text("No fake posts are shown.",fontSize=12.sp,color=Color.Gray)}}}}}
@Composable fun Team(){Column(Modifier.fillMaxSize().padding(16.dp)){Text("Team & Contributors",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Invite contributors and manage roles.",color=Color.Gray);Spacer(Modifier.height(16.dp));Button({},Modifier.fillMaxWidth()){Icon(Icons.Default.PersonAdd,null);Spacer(Modifier.width(8.dp));Text("Add Contributor")}}}
@Composable fun ModulePage(name:String){Column(Modifier.fillMaxSize().padding(16.dp)){Text(name,fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("Registered in the permanent app shell. Live schema and data will come from SANSTUDIOH Core.",color=Color.Gray);Spacer(Modifier.height(16.dp));Card(Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Extension,null,tint=Color(0xFFE50914));Spacer(Modifier.width(12.dp));Text("Waiting for Core API")}}}}
